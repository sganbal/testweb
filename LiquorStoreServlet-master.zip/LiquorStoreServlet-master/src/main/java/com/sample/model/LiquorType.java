package com.sample.model;

/**
 * Created by kasun on 5/24/17.
 */
public enum LiquorType {
    WINE,BEER,WHISKY

}
